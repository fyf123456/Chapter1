# chapter1
Android基础UI开发

* app:课堂代码
* homework:课后作业
* homework-debug.apk 是课后作业的示例，
(可以使用adb install -t homework-debug.apk 进行安装)

* Android基础UI开发.pdf 是随堂课件

## UI的标注资源 请参考这里：

https://app.zeplin.io/project/5c402caf0c6b0938570c4953/screen/5c402eaf5838d5bff1178c68

* 账号：397717749@qq.com
* 密码：123456

